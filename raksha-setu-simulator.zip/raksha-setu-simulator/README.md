# RAKSHA SETU
### Vehicle Crash & Impact Intelligence Simulator

A fully self-contained, browser-based demonstration of how vehicle motion and crash
parameters can be converted into structured crash intelligence: ΔV, deceleration,
G-force, estimated impact force, kinetic energy loss, severity classification,
a crash event ID, a crash timeline, and a printable crash report.

This is a **simulation for demonstration purposes only**. It does not connect to
any real vehicle, telematics device, GPS unit, IoT sensor, police system, ambulance
dispatch, or emergency-response service.

---

## How to run it

No installation, build step, or server is required.

1. Extract the ZIP.
2. Open the folder in VS Code (or any editor) — optional, just for viewing the code.
3. Double-click `index.html`, or right-click it and choose "Open with" your browser.
4. That's it. The simulator runs entirely client-side.

If you prefer, VS Code's "Live Server" extension also works, but it is **not required** —
opening the file directly is enough.

---

## What it demonstrates

```
VEHICLE PARAMETERS
      ↓
VEHICLE MOTION
      ↓
IMPACT EVENT
      ↓
CRASH TELEMETRY
      ↓
ΔV CALCULATION
      ↓
DECELERATION
      ↓
ESTIMATED IMPACT FORCE
      ↓
SEVERITY ANALYSIS
      ↓
CRASH EVENT GENERATED
      ↓
CRASH REPORT
```

The user (or jury member) controls:
- Vehicle mass (800–3000 kg)
- Initial speed (0–160 km/h)
- Impact (residual) speed (0–120 km/h)
- Impact duration (0.05–1.00 s)
- Impact type: Frontal / Rear / Side
- Road/environment condition: Dry / Wet / Gravel / Ice

The simulator computes and displays:
- Δ Velocity (ΔV)
- Deceleration (m/s²)
- G-force
- Estimated average impact force (kN)
- Kinetic energy lost (kJ)
- Crash severity classification (Minor / Moderate / Severe / Critical)
- A generated Crash Event ID
- A crash timeline
- A downloadable/printable crash report

Six preset scenarios (Parking Bump, City Intersection, Highway Rear-End,
Side Impact, Severe Collision, and Custom) are included so the jury can see
a range of outcomes quickly.

---

## Physics model (simplified, for demonstration)

- ΔV = Initial Speed − Impact Speed (converted to m/s)
- Deceleration = ΔV / Impact Duration, adjusted by an impact-type multiplier
  (side impacts are modeled as transmitting more force to the occupant compartment
  than frontal or rear impacts, reflecting typically smaller crumple zones)
- G-force = Deceleration / 9.81
- Average Impact Force = Vehicle Mass × Deceleration
- Kinetic Energy Lost = ½ × Mass × (Initial Speed² − Impact Speed²)
- Severity thresholds (by G-force): Minor < 5g, Moderate 5–15g, Severe 15–30g,
  Critical ≥ 30g

These are simplified, illustrative formulas intended to make the underlying
concepts clear to a non-specialist audience — they are not a substitute for
certified crash-test methodology or accident reconstruction analysis.

---

## Technology

- HTML5, CSS3, vanilla JavaScript (ES6+) — no frameworks, no build tools
- [Chart.js](https://www.chartjs.org/) is loaded from a CDN for the speed-vs-time
  chart. If the CDN is unreachable (e.g. no internet during the demo), the
  simulator automatically falls back to a plain numeric speed table so the rest
  of the app keeps working.

## File structure

```
raksha-setu-simulator/
├── index.html
├── style.css
├── script.js
├── README.md
└── assets/
    └── README.txt
```

## Future integration

In a real deployment, authorized vehicle/telematics data could replace these
simulated inputs. This build does not implement, simulate, or imply any
connection to real emergency-response infrastructure.
