This folder is reserved for any additional static assets (icons, images)
you may want to add to the RAKSHA SETU simulator.

The simulator currently uses inline SVG and emoji for all visuals, so no
image files are required for it to run.
