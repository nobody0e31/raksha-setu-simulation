/* =========================================================
   RAKSHA SETU — Vehicle Crash & Impact Intelligence Simulator
   Pure vanilla JS. No backend. No real vehicle/telematics data.
   ========================================================= */

(function () {
  "use strict";

  /* ---------------- DOM REFERENCES ---------------- */
  const massSlider = document.getElementById("massSlider");
  const initialSpeedSlider = document.getElementById("initialSpeedSlider");
  const impactSpeedSlider = document.getElementById("impactSpeedSlider");
  const durationSlider = document.getElementById("durationSlider");
  const roadConditionSelect = document.getElementById("roadCondition");

  const massValue = document.getElementById("massValue");
  const initialSpeedValue = document.getElementById("initialSpeedValue");
  const impactSpeedValue = document.getElementById("impactSpeedValue");
  const durationValue = document.getElementById("durationValue");

  const impactTypeButtons = document.querySelectorAll(".impact-type-btn");
  const presetButtons = document.querySelectorAll(".preset-btn");

  const runSimBtn = document.getElementById("runSimBtn");
  const resetBtn = document.getElementById("resetBtn");
  const reportBtn = document.getElementById("reportBtn");
  const startDemoBtn = document.getElementById("startDemoBtn");

  const liveSpeedEl = document.getElementById("liveSpeed");
  const liveTimeEl = document.getElementById("liveTime");
  const livePhaseEl = document.getElementById("livePhase");

  const metricDeltaV = document.getElementById("metricDeltaV");
  const metricDecel = document.getElementById("metricDecel");
  const metricGforce = document.getElementById("metricGforce");
  const metricForce = document.getElementById("metricForce");
  const metricKE = document.getElementById("metricKE");
  const metricSeverity = document.getElementById("metricSeverity");
  const severityCard = document.getElementById("severityCard");

  const crashEventIdEl = document.getElementById("crashEventId");
  const timelineList = document.getElementById("timelineList");

  const vehicleGroup = document.getElementById("vehicleGroup");
  const impactBurst = document.getElementById("impactBurst");

  const reportModal = document.getElementById("reportModal");
  const reportBody = document.getElementById("reportBody");
  const closeModal = document.getElementById("closeModal");
  const printReportBtn = document.getElementById("printReportBtn");

  const chartFallback = document.getElementById("chartFallback");
  const fallbackTable = document.getElementById("fallbackTable");

  const DEFAULTS = {
    mass: 1500,
    initialSpeed: 80,
    impactSpeed: 30,
    duration: 0.15,
    impactType: "FRONTAL",
    road: "dry"
  };

  let state = { ...DEFAULTS };
  let lastResult = null;
  let animationHandle = null;
  let speedChart = null;

  /* ---------------- PRESETS ---------------- */
  const PRESETS = {
    parking: { mass: 1200, initialSpeed: 12, impactSpeed: 2, duration: 0.35, impactType: "FRONTAL", road: "dry" },
    city: { mass: 1500, initialSpeed: 45, impactSpeed: 15, duration: 0.2, impactType: "FRONTAL", road: "dry" },
    "highway-rear": { mass: 1700, initialSpeed: 100, impactSpeed: 60, duration: 0.25, impactType: "REAR", road: "dry" },
    side: { mass: 1450, initialSpeed: 55, impactSpeed: 20, duration: 0.12, impactType: "SIDE", road: "wet" },
    severe: { mass: 1900, initialSpeed: 130, impactSpeed: 20, duration: 0.09, impactType: "FRONTAL", road: "dry" },
    custom: null
  };

  const ROAD_FRICTION_NOTE = {
    dry: "Dry asphalt — nominal grip, baseline crash dynamics.",
    wet: "Wet road — reduced tyre grip, longer pre-impact braking distance assumed.",
    gravel: "Gravel / loose surface — inconsistent traction, higher pre-impact instability.",
    ice: "Ice / snow — severely reduced grip, higher pre-impact speed retention likely."
  };

  const IMPACT_TYPE_MULTIPLIER = {
    FRONTAL: 1.0,
    REAR: 0.9,
    SIDE: 1.3
  };

  /* ---------------- UI SYNC HELPERS ---------------- */
  function kmhToMs(kmh) { return kmh / 3.6; }

  function syncControlsFromState() {
    massSlider.value = state.mass;
    initialSpeedSlider.value = state.initialSpeed;
    impactSpeedSlider.value = state.impactSpeed;
    durationSlider.value = state.duration;
    roadConditionSelect.value = state.road;

    massValue.textContent = `${state.mass} kg`;
    initialSpeedValue.textContent = `${state.initialSpeed} km/h`;
    impactSpeedValue.textContent = `${state.impactSpeed} km/h`;
    durationValue.textContent = `${Number(state.duration).toFixed(2)} s`;

    impactTypeButtons.forEach(btn => {
      btn.classList.toggle("active", btn.dataset.impact === state.impactType);
    });
  }

  function clearPresetHighlight(activeKey) {
    presetButtons.forEach(btn => {
      btn.classList.toggle("active", btn.dataset.preset === activeKey);
    });
  }

  /* ---------------- EVENT: SLIDERS / INPUTS ---------------- */
  massSlider.addEventListener("input", () => {
    state.mass = Number(massSlider.value);
    massValue.textContent = `${state.mass} kg`;
    clearPresetHighlight("custom");
  });

  initialSpeedSlider.addEventListener("input", () => {
    state.initialSpeed = Number(initialSpeedSlider.value);
    if (state.impactSpeed > state.initialSpeed) {
      state.impactSpeed = state.initialSpeed;
      impactSpeedSlider.value = state.impactSpeed;
      impactSpeedValue.textContent = `${state.impactSpeed} km/h`;
    }
    initialSpeedValue.textContent = `${state.initialSpeed} km/h`;
    clearPresetHighlight("custom");
  });

  impactSpeedSlider.addEventListener("input", () => {
    let val = Number(impactSpeedSlider.value);
    if (val > state.initialSpeed) {
      val = state.initialSpeed;
      impactSpeedSlider.value = val;
    }
    state.impactSpeed = val;
    impactSpeedValue.textContent = `${state.impactSpeed} km/h`;
    clearPresetHighlight("custom");
  });

  durationSlider.addEventListener("input", () => {
    state.duration = Number(durationSlider.value);
    durationValue.textContent = `${state.duration.toFixed(2)} s`;
    clearPresetHighlight("custom");
  });

  roadConditionSelect.addEventListener("change", () => {
    state.road = roadConditionSelect.value;
    clearPresetHighlight("custom");
  });

  impactTypeButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      state.impactType = btn.dataset.impact;
      impactTypeButtons.forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      clearPresetHighlight("custom");
    });
  });

  presetButtons.forEach(btn => {
    btn.addEventListener("click", () => {
      const key = btn.dataset.preset;
      clearPresetHighlight(key);
      if (key === "custom" || !PRESETS[key]) return;
      state = { ...PRESETS[key] };
      syncControlsFromState();
    });
  });

  resetBtn.addEventListener("click", () => {
    state = { ...DEFAULTS };
    syncControlsFromState();
    clearPresetHighlight(null);
  });

  startDemoBtn.addEventListener("click", () => {
    document.getElementById("simulator").scrollIntoView({ behavior: "smooth" });
  });

  /* ---------------- PHYSICS ---------------- */
  function computeCrashPhysics(s) {
    const vInitial = kmhToMs(s.initialSpeed); // m/s
    const vImpact = kmhToMs(s.impactSpeed);   // m/s
    const deltaV = Math.max(0, vInitial - vImpact); // m/s
    const duration = Math.max(0.01, s.duration);    // s

    const rawDecel = deltaV / duration; // m/s^2
    const typeMultiplier = IMPACT_TYPE_MULTIPLIER[s.impactType] || 1.0;
    const decel = rawDecel * typeMultiplier;

    const gForce = decel / 9.81;
    const avgForceN = s.mass * decel; // Newtons
    const avgForceKN = avgForceN / 1000;

    const keInitial = 0.5 * s.mass * vInitial * vInitial;
    const keImpact = 0.5 * s.mass * vImpact * vImpact;
    const keLostKJ = Math.max(0, (keInitial - keImpact) / 1000);

    let severity = "MINOR";
    if (gForce >= 30) severity = "CRITICAL";
    else if (gForce >= 15) severity = "SEVERE";
    else if (gForce >= 5) severity = "MODERATE";

    return {
      vInitial, vImpact, deltaV, duration,
      decel, gForce, avgForceKN, keLostKJ, severity,
      typeMultiplier
    };
  }

  function generateEventId() {
    const now = new Date();
    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, "0");
    const d = String(now.getDate()).padStart(2, "0");
    const rand = Math.floor(1000 + Math.random() * 9000);
    return `RS-${y}${m}${d}-${rand}`;
  }

  function severityClass(sev) {
    return {
      MINOR: "sev-minor",
      MODERATE: "sev-moderate",
      SEVERE: "sev-severe",
      CRITICAL: "sev-critical"
    }[sev] || "";
  }

  /* ---------------- TIMELINE ---------------- */
  function buildTimeline(s, result) {
    const events = [];
    events.push({ t: "T-1.0s", label: "Pre-impact cruise", detail: `Vehicle travelling at ${s.initialSpeed} km/h on ${s.road} surface.` });
    events.push({ t: "T-0.2s", label: "Hazard detected", detail: "Closing distance drops sharply; driver/system reaction window begins." });
    events.push({ t: "T-0.0s", label: `${s.impactType} impact begins`, detail: `Contact event starts. Duration modeled: ${result.duration.toFixed(2)} s.` });
    events.push({ t: `T+${(result.duration / 2).toFixed(2)}s`, label: "Peak deceleration", detail: `Approx. ${result.gForce.toFixed(1)} g experienced by occupants.` });
    events.push({ t: `T+${result.duration.toFixed(2)}s`, label: "Impact resolved", detail: `Residual speed ${s.impactSpeed} km/h. Severity classified as ${result.severity}.` });
    events.push({ t: `T+${(result.duration + 0.5).toFixed(2)}s`, label: "Crash event logged", detail: "Structured crash record generated for review." });
    return events;
  }

  function renderTimeline(events) {
    timelineList.innerHTML = "";
    events.forEach(ev => {
      const li = document.createElement("li");
      li.innerHTML = `<strong>${ev.t} — ${ev.label}</strong>${ev.detail}`;
      timelineList.appendChild(li);
    });
  }

  /* ---------------- CHART ---------------- */
  function buildSpeedProfile(s, result) {
    const points = [];
    const preSeconds = 1.0;
    const steps = 20;
    for (let i = 0; i <= steps; i++) {
      const t = -(preSeconds) + (preSeconds * i) / steps;
      points.push({ t: Number(t.toFixed(2)), v: s.initialSpeed });
    }
    const impactSteps = 12;
    for (let i = 1; i <= impactSteps; i++) {
      const t = (result.duration * i) / impactSteps;
      const v = s.initialSpeed - ((s.initialSpeed - s.impactSpeed) * i) / impactSteps;
      points.push({ t: Number(t.toFixed(3)), v: Number(v.toFixed(1)) });
    }
    const postSteps = 6;
    for (let i = 1; i <= postSteps; i++) {
      const t = result.duration + (0.4 * i) / postSteps;
      points.push({ t: Number(t.toFixed(2)), v: s.impactSpeed });
    }
    return points;
  }

  function renderChart(points) {
    const canvas = document.getElementById("speedChart");
    if (typeof Chart === "undefined") {
      canvas.style.display = "none";
      chartFallback.style.display = "block";
      fallbackTable.innerHTML =
        "<table style='width:100%;border-collapse:collapse;'>" +
        points.filter((_, i) => i % 3 === 0).map(p =>
          `<tr><td style="padding:4px;border-bottom:1px solid #e2e8f0;">t = ${p.t}s</td><td style="padding:4px;border-bottom:1px solid #e2e8f0;text-align:right;">${p.v} km/h</td></tr>`
        ).join("") + "</table>";
      return;
    }
    canvas.style.display = "block";
    chartFallback.style.display = "none";

    const labels = points.map(p => `${p.t}s`);
    const data = points.map(p => p.v);

    if (speedChart) {
      speedChart.data.labels = labels;
      speedChart.data.datasets[0].data = data;
      speedChart.update();
      return;
    }

    speedChart = new Chart(canvas.getContext("2d"), {
      type: "line",
      data: {
        labels,
        datasets: [{
          label: "Vehicle Speed (km/h)",
          data,
          borderColor: "#2563eb",
          backgroundColor: "rgba(37,99,235,0.12)",
          fill: true,
          tension: 0.25,
          pointRadius: 0,
          borderWidth: 2.5
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: {
          x: { title: { display: true, text: "Time (s)" }, grid: { display: false } },
          y: { title: { display: true, text: "Speed (km/h)" }, beginAtZero: true }
        }
      }
    });
  }

  /* ---------------- VEHICLE ANIMATION ---------------- */
  function animateVehicle(s, result) {
    if (animationHandle) cancelAnimationFrame(animationHandle);
    impactBurst.innerHTML = "";
    impactBurst.setAttribute("opacity", "0");

    const startX = 40;
    const impactX = 430; // where the barrier sits
    const totalPreMs = 1400; // visual travel time before impact
    const impactMs = Math.max(150, result.duration * 1000 * 3); // stretched for visibility
    const startTime = performance.now();

    livePhaseEl.textContent = "Approaching";

    function frame(now) {
      const elapsed = now - startTime;

      if (elapsed <= totalPreMs) {
        const progress = elapsed / totalPreMs;
        const x = startX + (impactX - startX) * progress;
        vehicleGroup.setAttribute("transform", `translate(${x},140)`);
        liveSpeedEl.textContent = `${s.initialSpeed} km/h`;
        liveTimeEl.textContent = `${(elapsed / 1000).toFixed(2)} s`;
        livePhaseEl.textContent = "Approaching";
        animationHandle = requestAnimationFrame(frame);
      } else if (elapsed <= totalPreMs + impactMs) {
        const progress = (elapsed - totalPreMs) / impactMs;
        const speedNow = s.initialSpeed - (s.initialSpeed - s.impactSpeed) * progress;
        const shake = Math.sin(elapsed / 18) * 4 * (1 - progress);
        vehicleGroup.setAttribute("transform", `translate(${impactX + shake},140)`);
        liveSpeedEl.textContent = `${speedNow.toFixed(0)} km/h`;
        liveTimeEl.textContent = `${(elapsed / 1000).toFixed(2)} s`;
        livePhaseEl.textContent = "Impact";
        impactBurst.setAttribute("opacity", "1");
        impactBurst.setAttribute("transform", `translate(${impactX + 60},130)`);
        impactBurst.innerHTML = `
          <circle r="${18 + progress * 22}" fill="var(--critical-red)" opacity="${0.35 * (1 - progress)}"></circle>
          <circle r="${8 + progress * 10}" fill="var(--warn-orange)" opacity="${0.6 * (1 - progress)}"></circle>
        `;
        animationHandle = requestAnimationFrame(frame);
      } else {
        vehicleGroup.setAttribute("transform", `translate(${impactX},140)`);
        liveSpeedEl.textContent = `${s.impactSpeed} km/h`;
        liveTimeEl.textContent = `${((totalPreMs + impactMs) / 1000).toFixed(2)} s`;
        livePhaseEl.textContent = "Resolved";
        impactBurst.setAttribute("opacity", "0");
      }
    }
    animationHandle = requestAnimationFrame(frame);
  }

  /* ---------------- RUN SIMULATION ---------------- */
  function runSimulation() {
    const result = computeCrashPhysics(state);
    lastResult = { state: { ...state }, result, eventId: generateEventId(), timestamp: new Date() };

    metricDeltaV.textContent = `${result.deltaV.toFixed(2)} m/s`;
    metricDecel.textContent = `${result.decel.toFixed(1)} m/s²`;
    metricGforce.textContent = `${result.gForce.toFixed(1)} g`;
    metricForce.textContent = `${result.avgForceKN.toFixed(1)} kN`;
    metricKE.textContent = `${result.keLostKJ.toFixed(1)} kJ`;
    metricSeverity.textContent = result.severity;

    severityCard.className = `metric-card severity-card ${severityClass(result.severity)}`;

    crashEventIdEl.textContent = lastResult.eventId;

    const timeline = buildTimeline(state, result);
    renderTimeline(timeline);
    lastResult.timeline = timeline;

    const points = buildSpeedProfile(state, result);
    renderChart(points);

    animateVehicle(state, result);

    reportBtn.disabled = false;
  }

  runSimBtn.addEventListener("click", runSimulation);

  /* ---------------- CRASH REPORT ---------------- */
  function buildReportHtml() {
    if (!lastResult) return "<p>No simulation has been run yet.</p>";
    const { state: s, result, eventId, timestamp, timeline } = lastResult;

    const row = (label, value) => `<tr><td>${label}</td><td>${value}</td></tr>`;

    return `
      <h4>Event Summary</h4>
      <table>
        ${row("Crash Event ID", eventId)}
        ${row("Generated At", timestamp.toLocaleString())}
        ${row("Impact Type", s.impactType)}
        ${row("Road Condition", ROAD_FRICTION_NOTE[s.road])}
      </table>

      <h4>Simulated Vehicle Parameters</h4>
      <table>
        ${row("Vehicle Mass", `${s.mass} kg`)}
        ${row("Initial Speed", `${s.initialSpeed} km/h`)}
        ${row("Impact Speed", `${s.impactSpeed} km/h`)}
        ${row("Impact Duration", `${s.duration.toFixed(2)} s`)}
      </table>

      <h4>Computed Crash Intelligence</h4>
      <table>
        ${row("Δ Velocity (ΔV)", `${result.deltaV.toFixed(2)} m/s`)}
        ${row("Deceleration", `${result.decel.toFixed(1)} m/s²`)}
        ${row("G-Force", `${result.gForce.toFixed(1)} g`)}
        ${row("Avg. Impact Force", `${result.avgForceKN.toFixed(1)} kN`)}
        ${row("Kinetic Energy Lost", `${result.keLostKJ.toFixed(1)} kJ`)}
        ${row("Crash Severity", result.severity)}
      </table>

      <h4>Crash Timeline</h4>
      <table>
        ${timeline.map(ev => row(`${ev.t} — ${ev.label}`, ev.detail)).join("")}
      </table>

      <h4>Disclaimer</h4>
      <p style="color:#5b6478;font-size:0.8rem;">
        This report is generated from a simulated demonstration environment for RAKSHA SETU.
        All parameters were manually configured for demonstration purposes. This report is not derived from
        a real vehicle, telematics device, or emergency-services record.
      </p>
    `;
  }

  reportBtn.addEventListener("click", () => {
    reportBody.innerHTML = buildReportHtml();
    reportModal.classList.add("open");
  });

  closeModal.addEventListener("click", () => reportModal.classList.remove("open"));
  reportModal.addEventListener("click", (e) => {
    if (e.target === reportModal) reportModal.classList.remove("open");
  });

  printReportBtn.addEventListener("click", () => {
    const printWindow = window.open("", "_blank");
    printWindow.document.write(`
      <html><head><title>Raksha Setu Crash Report</title>
      <style>
        body{font-family:Arial,sans-serif;padding:24px;color:#1c2536;}
        h4{color:#1e3a8a;margin-top:18px;}
        table{width:100%;border-collapse:collapse;margin-bottom:10px;}
        td{padding:6px 4px;border-bottom:1px solid #e2e8f0;font-size:13px;}
      </style></head><body>
      <h2>Raksha Setu — Crash Intelligence Report</h2>
      ${buildReportHtml()}
      </body></html>
    `);
    printWindow.document.close();
    printWindow.focus();
    setTimeout(() => printWindow.print(), 300);
  });

  /* ---------------- INIT ---------------- */
  syncControlsFromState();
})();
